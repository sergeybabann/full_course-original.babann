const Card = () => {
  return (
    <>
      <h1>Bogdan</h1>
      <h3>I am recording React course</h3>
      <button>Like!</button>
    </>
  )
}

export default Card
