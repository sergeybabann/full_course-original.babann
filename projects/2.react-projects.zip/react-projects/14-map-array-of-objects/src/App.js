import './App.css'
import Persons from './components/Persons'

function App() {
  return (
    <div className="App">
      <Persons />
    </div>
  )
}

export default App
